# PDF Saathi v0.6 — Android project

Native Kotlin + Jetpack Compose Android app for reading and annotating PDFs.

## Changes in v0.6
- Avoids restarting the gesture detector on every zoom/pan update; this should reduce stutter while dragging.
- Pinch zoom is focal-point-aware and keeps the point under the fingers more stable.
- Tools are organized in a navigation sidebar.
- Undo/redo for unsaved annotation strokes and markup.
- Back button closes the sidebar first, then returns from the open PDF to the home screen instead of immediately exiting the app.
- Existing PDFBox-Android based password opening and annotation/save functionality retained.

## Existing features
- Open PDFs through Android document picker
- Password prompt for encrypted PDFs (password support depends on PDF encryption compatibility)
- Page navigation, zoom and pan
- Highlight, underline, freehand drawing, drawn signature
- Save annotations to a new PDF, rotate current page, add a text note, save a copy, share PDF

## Build on GitHub Actions
Upload `PDFSaathiAndroid_v0.6.zip` to the repository root and replace `.github/workflows/android.yml` with the provided `PDFSaathi_android_build_v0.6.yml` content. Commit both, then open Actions and download the `PDFSaathi-debug-apk` artifact after a successful run.

## Limitations / testing
This project has not been compiled or device-tested in this environment. Verify the GitHub Actions build and test pan/zoom, back behavior, undo/redo, password-protected PDFs, and save output on-device. Undo/redo covers pending annotations before they are saved; it does not revert edits after exporting a new PDF. A drawn signature is visual, not a certificate-based cryptographic signature. Advanced features such as OCR, form filling, merging/splitting, and editing existing text are not implemented yet.
