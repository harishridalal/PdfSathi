# PDF Saathi v0.3 — Reader foundation

## Updated in this version
- Pinch-to-zoom uses Compose `transformable` state (two-finger zoom from 100% to 500%) and has zoom +/- and reset controls.
- Password-protected PDF loading uses PDFBox-Android, so it is not restricted to Android 15's built-in PdfRenderer password API.
- Password prompt retries on an incorrect password.
- PDF page rendering and document parsing run on IO dispatcher.

## Build from phone using GitHub Actions
1. Upload `PDFSaathiAndroid_v0.3.zip` to the root of your GitHub repository.
2. Upload the supplied `.github/workflows/android.yml` to the repository path `.github/workflows/android.yml` (replace the old workflow).
3. Commit both files. The workflow extracts the new ZIP every run, builds the APK, and uploads `PDFSaathi-debug-apk` as an artifact.
4. Open Actions > successful run > Artifacts and download/extract the APK ZIP.

## Scope and limitations
This is still a reader-focused build, not a complete Acrobat replacement. Editing existing text, saved annotations, signatures, forms, page management, OCR, merge/split and conversion are not implemented yet. Build/test on GitHub Actions is required before treating this version as verified. Very large PDFs can require significant memory. The user must know the correct PDF password; the app does not bypass encryption.
