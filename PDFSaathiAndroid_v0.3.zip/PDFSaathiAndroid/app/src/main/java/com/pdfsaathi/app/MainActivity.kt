package com.pdfsaathi.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.rendering.ImageType
import com.tom_roush.pdfbox.rendering.PDFRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF172033)
private val Blue = Color(0xFF315EFB)
private val CanvasBg = Color(0xFFF2F4F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PdfSaathiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfSaathiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfName by remember { mutableStateOf("No PDF opened") }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pdfPassword by remember { mutableStateOf<String?>(null) }
    var passwordInput by remember { mutableStateOf("") }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            pdfUri = uri
            pdfName = queryDisplayName(context, uri) ?: "Document.pdf"
            currentPage = 0
            pageCount = 0
            zoom = 1f
            pdfPassword = null
            passwordInput = ""
            passwordError = null
            showPasswordDialog = false
            error = null
        }
    }

    LaunchedEffect(pdfUri, pdfPassword) {
        val uri = pdfUri ?: return@LaunchedEffect
        busy = true
        try {
            val count = withContext(Dispatchers.IO) {
                loadDocument(context, uri, pdfPassword).use { it.numberOfPages }
            }
            pageCount = count
            currentPage = currentPage.coerceIn(0, (count - 1).coerceAtLeast(0))
            error = null
            showPasswordDialog = false
            passwordError = null
        } catch (e: InvalidPasswordException) {
            pageCount = 0
            passwordError = if (pdfPassword.isNullOrEmpty()) {
                "Yeh PDF password-protected hai. Password enter karo."
            } else {
                "Password galat hai. Dobara try karo."
            }
            passwordInput = ""
            showPasswordDialog = true
        } catch (e: Exception) {
            pageCount = 0
            error = "PDF open nahi hui: ${e.localizedMessage ?: "file damaged ya unsupported ho sakti hai"}"
        } finally {
            busy = false
        }
    }

    val transformState = rememberTransformableState { zoomChange, _, _ ->
        zoom = (zoom * zoomChange).coerceIn(1f, 5f)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            onPrimary = Color.White,
            background = CanvasBg,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PDF Saathi", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text(pdfName, fontSize = 11.sp, maxLines = 1)
                        }
                    },
                    actions = {
                        IconButton(onClick = { picker.launch(arrayOf("application/pdf")) }) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "Open PDF")
                        }
                        IconButton(onClick = { showTools = !showTools }) {
                            Icon(Icons.Default.Edit, contentDescription = "PDF tools")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                if (pageCount > 0) {
                    Surface(shadowElevation = 8.dp, color = Color.White) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(onClick = {
                                currentPage = (currentPage - 1).coerceAtLeast(0)
                                zoom = 1f
                            }) { Icon(Icons.Default.ChevronLeft, contentDescription = "Previous page") }
                            Text("Page ${currentPage + 1} of $pageCount", fontWeight = FontWeight.SemiBold)
                            IconButton(onClick = {
                                currentPage = (currentPage + 1).coerceAtMost(pageCount - 1)
                                zoom = 1f
                            }) { Icon(Icons.Default.ChevronRight, contentDescription = "Next page") }
                        }
                    }
                }
            },
            containerColor = CanvasBg
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (showTools) {
                    Card(
                        Modifier.fillMaxWidth().padding(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PDF Reader tools", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Pinch with two fingers to zoom. Password-protected PDFs are handled by the PDF engine.", fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AssistChip(onClick = { zoom = (zoom - 0.2f).coerceAtLeast(1f) }, label = { Text("Zoom −") })
                                AssistChip(onClick = { zoom = (zoom + 0.2f).coerceAtMost(5f) }, label = { Text("Zoom +") })
                                AssistChip(onClick = { zoom = 1f }, label = { Text("Reset") })
                                AssistChip(onClick = { sharePdf(context, pdfUri) }, label = { Text("Share") }, leadingIcon = { Icon(Icons.Default.Share, null) })
                            }
                            Text("Advanced editing (markup, signatures, forms, page tools, OCR) is not implemented in this build yet.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                when {
                    busy && pageCount == 0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    error != null -> EmptyState("PDF open nahi hui", error ?: "", "Try another PDF") {
                        error = null
                        picker.launch(arrayOf("application/pdf"))
                    }
                    pdfUri == null -> EmptyState(
                        "Your PDFs, one place",
                        "PDF kholne ke liye button dabao. File Android document picker se select hogi.",
                        "Open a PDF"
                    ) { picker.launch(arrayOf("application/pdf")) }
                    pageCount == 0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Password enter karke PDF open karo.", color = Color.Gray)
                    }
                    else -> {
                        val uri = pdfUri!!
                        val pageIndex = currentPage.coerceIn(0, pageCount - 1)
                        val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = uri, key2 = pageIndex, key3 = pdfPassword) {
                            value = withContext(Dispatchers.IO) { renderPage(context, uri, pageIndex, pdfPassword) }
                        }
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            item {
                                Row(
                                    Modifier.fillMaxWidth().padding(bottom = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(pdfName, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    Text("${(zoom * 100).toInt()}%", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                            item {
                                if (bitmap != null) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                                    ) {
                                        Image(
                                            bitmap = bitmap!!.asImageBitmap(),
                                            contentDescription = "PDF page ${pageIndex + 1}",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(2.dp)
                                                .graphicsLayer { scaleX = zoom; scaleY = zoom }
                                                .transformable(state = transformState)
                                        )
                                    }
                                } else {
                                    Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator()
                                    }
                                }
                            }
                            item {
                                Text("PDF page ${pageIndex + 1}", Modifier.padding(14.dp), color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        if (showPasswordDialog) {
            AlertDialog(
                onDismissRequest = { /* Keep prompt open until user chooses Open or Cancel. */ },
                title = { Text("PDF password required") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Is PDF ko kholne ke liye uska password enter karo.")
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it; passwordError = null },
                            label = { Text("PDF password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            isError = passwordError != null
                        )
                        if (passwordError != null) Text(passwordError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (passwordInput.isNotEmpty()) {
                            pdfPassword = passwordInput
                            error = null
                        } else passwordError = "Password enter karo."
                    }) { Text("Open PDF") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showPasswordDialog = false
                        pdfPassword = null
                        pdfUri = null
                        pdfName = "No PDF opened"
                        pageCount = 0
                        error = null
                    }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String, buttonText: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Blue, modifier = Modifier.size(64.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(body, color = Color.Gray)
            Button(onClick = onClick) {
                Icon(Icons.Default.FolderOpen, null)
                Spacer(Modifier.width(8.dp))
                Text(buttonText)
            }
        }
    }
}

private fun queryDisplayName(context: Context, uri: Uri): String? {
    return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }
}

private fun loadDocument(context: Context, uri: Uri, password: String?): PDDocument {
    PDFBoxResourceLoader.init(context.applicationContext)
    val input = context.contentResolver.openInputStream(uri)
        ?: throw IllegalStateException("File open nahi ho paayi.")
    return input.use { PDDocument.load(it, password ?: "") }
}

private fun renderPage(context: Context, uri: Uri, index: Int, password: String?): android.graphics.Bitmap? {
    return try {
        loadDocument(context, uri, password).use { document ->
            if (index !in 0 until document.numberOfPages) return null
            PDFRenderer(document).renderImage(index, 1.5f, ImageType.RGB)
        }
    } catch (_: Exception) {
        null
    }
}

private fun sharePdf(context: Context, uri: Uri?) {
    if (uri == null) return
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share PDF"))
}
