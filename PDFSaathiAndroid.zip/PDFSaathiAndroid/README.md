# PDF Saathi — Android project starter

This is a native Kotlin + Jetpack Compose Android Studio project for a PDF reader MVP.

## Current working features
- Open PDF from Android's document picker (no broad storage permission)
- Render the selected PDF page using Android `PdfRenderer`
- Previous/next page navigation
- Zoom controls (re-render based)
- Share the currently opened PDF
- Basic Compose UI

## Important limitation
This starter is **not yet an Adobe Acrobat replacement**. The tools panel is explicitly a roadmap, not functional editing. Android's built-in `PdfRenderer` is a renderer, not a full PDF editing engine. Real text editing, annotations persisted to PDF, signatures, form filling, merge/split, OCR, compression and conversion require additional tested libraries and implementation.

## Build
1. Open this folder in Android Studio (Hedgehog or newer recommended).
2. Install Android SDK 35 and JDK 17.
3. Let Gradle sync.
4. Run on an Android device or emulator.

The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.

## Suggested implementation phases
1. Reliable reader: thumbnails, continuous scrolling, page jump, search/text extraction, bookmarks and recent files.
2. Markup: highlight, underline, strikeout, freehand drawing, notes and stamps; save annotations into the PDF.
3. Document editing: rotate/reorder/delete pages, merge/split, password-protected PDFs, metadata.
4. Forms and signatures: fill forms, create/import signature, flatten/export.
5. Export tools: image-to-PDF, PDF-to-image/text, compression, OCR for scanned PDFs.
6. Advanced text editing: edit existing PDF text where technically possible; this is more complex than annotation and depends on fonts/layout in each PDF.
7. QA: test on scanned, encrypted, large and malformed PDFs, plus accessibility and memory usage.

## Product note
Before publishing, review all dependency licenses and add privacy policy, crash reporting choices, and a proper test suite. PDF contents should remain on-device unless the user explicitly chooses a cloud/OCR service.
