# PDF Saathi Android — v0.5

Native Android PDF reader/editor starter built with Kotlin, Jetpack Compose and PDFBox-Android.

## Implemented in this version
- Open PDFs using Android document picker
- Password prompt for password-protected PDFs (PDFBox-supported encryption)
- PDF page rendering and previous/next navigation
- Pinch zoom and pan in Pan / Zoom mode
- Add PDF highlight and underline markup annotations
- Freehand drawing and drawn signature strokes
- Save annotations into a new PDF copy
- Rotate current page, add a text stamp, save a copy, share the current PDF
- Original file is not overwritten when saving edits

## Important scope and limitations
- A drawn signature is a visual signature, **not** a certificate-backed cryptographic digital signature.
- Highlight/underline uses a drag gesture to mark a rectangular region; it does not automatically select text.
- Text stamping currently supports basic Latin characters because it uses PDFBox Helvetica.
- Editing and saving may not work with every malformed PDF, unsupported encryption variant, signed/certified document, or document with special permissions. Test on a copy first.
- OCR, full existing-text replacement, AcroForm editing, page merge/split/reorder, compression and conversion are not implemented yet.
- The source has not been built or device-tested in this environment. Run the GitHub Actions build before installing.

## Build with GitHub Actions from a phone
1. Upload this project ZIP to the repository root as `PDFSaathiAndroid_v0.5.zip`.
2. Replace `.github/workflows/android.yml` with the supplied `PDFSaathi_android_build_v0.5.yml` content (the workflow expects that exact ZIP name).
3. Commit changes, then open Actions and wait for the build to finish.
4. Download `PDFSaathi-debug-apk` from Artifacts, extract it and install `app-debug.apk`.

## Tool interaction
- Pan / Zoom: one-finger drag pans, two-finger pinch zooms.
- Highlight / Underline / Draw / Signature: drag directly on the page to add marks, then tap Save annotations.
