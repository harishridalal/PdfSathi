package com.pdfsaathi.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup
import com.tom_roush.pdfbox.rendering.ImageType
import com.tom_roush.pdfbox.rendering.PDFRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val Ink = Color(0xFF172033)
private val Blue = Color(0xFF315EFB)
private val CanvasBg = Color(0xFFF2F4F8)

private data class PdfMark(
    val type: String,
    val pageIndex: Int,
    val points: List<Offset>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PdfSaathiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfSaathiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfName by remember { mutableStateOf("No PDF opened") }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pdfPassword by remember { mutableStateOf<String?>(null) }
    var passwordInput by remember { mutableStateOf("") }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var showTextDialog by remember { mutableStateOf(false) }
    var noteText by remember { mutableStateOf("") }
    var pendingEdit by remember { mutableStateOf("copy") }
    var editStatus by remember { mutableStateOf<String?>(null) }
    var activeTool by remember { mutableStateOf("pan") }
    var inProgressPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val marks = remember { mutableStateListOf<PdfMark>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            pdfUri = uri
            pdfName = queryDisplayName(context, uri) ?: "Document.pdf"
            currentPage = 0
            pageCount = 0
            zoom = 1f
            panOffset = Offset.Zero
            editStatus = null
            marks.clear()
            inProgressPoints = emptyList()
            pdfPassword = null
            passwordInput = ""
            passwordError = null
            showPasswordDialog = false
            error = null
        }
    }

    val savePdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { outputUri ->
        val sourceUri = pdfUri
        if (outputUri != null && sourceUri != null) {
            busy = true
            editStatus = null
            val operation = pendingEdit
            val note = noteText
            val password = pdfPassword
            val marksToSave = marks.toList()
            coroutineScope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        loadDocument(context, sourceUri, password).use { doc ->
                            when (operation) {
                                "rotate" -> {
                                    val page = doc.getPage(currentPage)
                                    page.rotation = (page.rotation + 90) % 360
                                }
                                "note" -> {
                                    val page = doc.getPage(currentPage)
                                    PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { stream ->
                                        stream.beginText()
                                        stream.setFont(PDType1Font.HELVETICA, 14f)
                                        stream.setNonStrokingColor(35, 75, 180)
                                        stream.newLineAtOffset(48f, (page.mediaBox.height - 56f).coerceAtLeast(24f))
                                        val safeNote = note.filter { it.code in 32..255 }.take(180)
                                        stream.showText(safeNote.ifBlank { "PDF Saathi note" })
                                        stream.endText()
                                    }
                                }
                                "annotations" -> {
                                    if (marksToSave.isEmpty()) throw IllegalStateException("Pehle highlight, underline, drawing ya signature add karo.")
                                    marksToSave.forEach { mark ->
                                        if (mark.pageIndex !in 0 until doc.numberOfPages || mark.points.isEmpty()) return@forEach
                                        val page = doc.getPage(mark.pageIndex)
                                        val box = page.mediaBox
                                        when (mark.type) {
                                            "highlight", "underline" -> {
                                                val first = mark.points.first()
                                                val last = mark.points.last()
                                                val x1 = min(first.x, last.x).coerceIn(0f, 1f) * box.width
                                                val x2 = max(first.x, last.x).coerceIn(0f, 1f) * box.width
                                                val yTop = (1f - min(first.y, last.y).coerceIn(0f, 1f)) * box.height
                                                val yBottom = (1f - max(first.y, last.y).coerceIn(0f, 1f)) * box.height
                                                val left = min(x1, x2)
                                                val right = max(x1, x2)
                                                val bottom = min(yBottom, yTop)
                                                val top = max(yBottom, yTop)
                                                val minWidth = 8f
                                                val minHeight = if (mark.type == "highlight") 12f else 8f
                                                val l = (if (right - left < minWidth) (left - minWidth / 2f).coerceAtLeast(0f) else left)
                                                val r = (if (right - left < minWidth) (right + minWidth / 2f).coerceAtMost(box.width) else right)
                                                val b = (if (top - bottom < minHeight) (bottom - minHeight / 2f).coerceAtLeast(0f) else bottom)
                                                val t = (if (top - bottom < minHeight) (top + minHeight / 2f).coerceAtMost(box.height) else top)
                                                val subtype = if (mark.type == "highlight") PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT else PDAnnotationTextMarkup.SUB_TYPE_UNDERLINE
                                                val annotation = PDAnnotationTextMarkup(subtype)
                                                annotation.rectangle = PDRectangle(l, b, (r - l).coerceAtLeast(1f), (t - b).coerceAtLeast(1f))
                                                annotation.quadPoints = floatArrayOf(l, t, r, t, l, b, r, b)
                                                annotation.color = if (mark.type == "highlight") PDColor(floatArrayOf(1f, 0.88f, 0.1f), PDDeviceRGB.INSTANCE) else PDColor(floatArrayOf(0.1f, 0.3f, 0.95f), PDDeviceRGB.INSTANCE)
                                                if (mark.type == "highlight") annotation.constantOpacity = 0.35f
                                                page.annotations.add(annotation)
                                            }
                                            "draw", "signature" -> {
                                                val pts = mark.points
                                                if (pts.size < 2) return@forEach
                                                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { stream ->
                                                    if (mark.type == "signature") {
                                                        stream.setStrokingColor(20, 40, 130)
                                                        stream.setLineWidth(2.2f)
                                                    } else {
                                                        stream.setStrokingColor(30, 70, 210)
                                                        stream.setLineWidth(1.5f)
                                                    }
                                                    stream.setLineCapStyle(1)
                                                    stream.setLineJoinStyle(1)
                                                    stream.moveTo(pts.first().x.coerceIn(0f, 1f) * box.width, (1f - pts.first().y.coerceIn(0f, 1f)) * box.height)
                                                    pts.drop(1).forEach { p ->
                                                        stream.lineTo(p.x.coerceIn(0f, 1f) * box.width, (1f - p.y.coerceIn(0f, 1f)) * box.height)
                                                    }
                                                    stream.stroke()
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            context.contentResolver.openOutputStream(outputUri, "w")?.use { out -> doc.save(out) }
                                ?: throw IllegalStateException("Output file create nahi ho paayi")
                        }
                    }
                    pdfUri = outputUri
                    pdfName = queryDisplayName(context, outputUri) ?: "PDFSaathi-edited.pdf"
                    editStatus = when (operation) {
                        "rotate" -> "Current page rotate karke nayi PDF save ho gayi."
                        "note" -> "Text note PDF mein add karke save ho gaya."
                        "annotations" -> "${marksToSave.size} annotation stroke/markup save ho gaye. Original PDF alag rahi."
                        else -> "PDF copy save ho gayi."
                    }
                    marks.clear()
                    zoom = 1f
                    panOffset = Offset.Zero
                } catch (e: Exception) {
                    editStatus = "Save failed: ${e.localizedMessage ?: "PDF edit nahi ho paayi"}"
                } finally {
                    busy = false
                }
            }
        }
    }

    LaunchedEffect(pdfUri, pdfPassword) {
        val uri = pdfUri ?: return@LaunchedEffect
        busy = true
        try {
            val count = withContext(Dispatchers.IO) { loadDocument(context, uri, pdfPassword).use { it.numberOfPages } }
            pageCount = count
            currentPage = currentPage.coerceIn(0, (count - 1).coerceAtLeast(0))
            error = null
            showPasswordDialog = false
            passwordError = null
        } catch (e: InvalidPasswordException) {
            pageCount = 0
            passwordError = if (pdfPassword.isNullOrEmpty()) "Yeh PDF password-protected hai. Password enter karo." else "Password galat hai. Dobara try karo."
            passwordInput = ""
            showPasswordDialog = true
        } catch (e: Exception) {
            pageCount = 0
            error = "PDF open nahi hui: ${e.localizedMessage ?: "file damaged ya unsupported ho sakti hai"}"
        } finally { busy = false }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, onPrimary = Color.White, background = CanvasBg, surface = Color.White, onSurface = Ink)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text("PDF Saathi", fontWeight = FontWeight.Bold, fontSize = 20.sp); Text(pdfName, fontSize = 11.sp, maxLines = 1) } },
                    actions = {
                        IconButton(onClick = { picker.launch(arrayOf("application/pdf")) }) { Icon(Icons.Default.FolderOpen, contentDescription = "Open PDF") }
                        IconButton(onClick = { showTools = !showTools }) { Icon(Icons.Default.Edit, contentDescription = "PDF tools") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                if (pageCount > 0) Surface(shadowElevation = 8.dp, color = Color.White) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        IconButton(onClick = { currentPage = (currentPage - 1).coerceAtLeast(0); zoom = 1f; panOffset = Offset.Zero }) { Icon(Icons.Default.ChevronLeft, contentDescription = "Previous page") }
                        Text("Page ${currentPage + 1} of $pageCount", fontWeight = FontWeight.SemiBold)
                        IconButton(onClick = { currentPage = (currentPage + 1).coerceAtMost(pageCount - 1); zoom = 1f; panOffset = Offset.Zero }) { Icon(Icons.Default.ChevronRight, contentDescription = "Next page") }
                    }
                }
            },
            containerColor = CanvasBg
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (showTools) {
                    Card(Modifier.fillMaxWidth().padding(10.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PDF Editor tools", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Pan mode: one finger move, two fingers zoom. Annotation mode: drag on page, then save a new PDF.", fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ToolChip("Pan / Zoom", activeTool == "pan") { activeTool = "pan" }
                                ToolChip("Highlight", activeTool == "highlight") { activeTool = "highlight" }
                                ToolChip("Underline", activeTool == "underline") { activeTool = "underline" }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ToolChip("Draw", activeTool == "draw") { activeTool = "draw" }
                                ToolChip("Signature", activeTool == "signature") { activeTool = "signature" }
                                AssistChip(onClick = { marks.clear(); inProgressPoints = emptyList(); editStatus = "Unsaved annotations cleared." }, label = { Text("Clear marks") })
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AssistChip(onClick = { zoom = (zoom - 0.2f).coerceAtLeast(1f); if (zoom <= 1f) panOffset = Offset.Zero }, label = { Text("Zoom −") })
                                AssistChip(onClick = { zoom = (zoom + 0.2f).coerceAtMost(5f) }, label = { Text("Zoom +") })
                                AssistChip(onClick = { zoom = 1f; panOffset = Offset.Zero }, label = { Text("Reset") })
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AssistChip(onClick = { pendingEdit = "rotate"; savePdfLauncher.launch("PDFSaathi-rotated.pdf") }, label = { Text("Rotate page") })
                                AssistChip(onClick = { noteText = ""; showTextDialog = true }, label = { Text("Text note") })
                                AssistChip(onClick = { pendingEdit = "copy"; savePdfLauncher.launch("PDFSaathi-copy.pdf") }, label = { Text("Save copy") })
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AssistChip(onClick = { pendingEdit = "annotations"; savePdfLauncher.launch("PDFSaathi-annotated.pdf") }, enabled = marks.isNotEmpty(), label = { Text("Save annotations (${marks.size})") })
                                AssistChip(onClick = { sharePdf(context, pdfUri) }, label = { Text("Share") }, leadingIcon = { Icon(Icons.Default.Share, null) })
                            }
                            editStatus?.let { Text(it, fontSize = 12.sp, color = if (it.startsWith("Save failed")) MaterialTheme.colorScheme.error else Blue) }
                            Text("Highlight/underline, freehand drawing and a drawn signature are saved into a new PDF. A drawn signature is not a cryptographic digital certificate signature.", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                when {
                    busy && pageCount == 0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    error != null -> EmptyState("PDF open nahi hui", error ?: "", "Try another PDF") { error = null; picker.launch(arrayOf("application/pdf")) }
                    pdfUri == null -> EmptyState("Your PDFs, one place", "PDF kholne ke liye button dabao. File Android document picker se select hogi.", "Open a PDF") { picker.launch(arrayOf("application/pdf")) }
                    pageCount == 0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Password enter karke PDF open karo.", color = Color.Gray) }
                    else -> {
                        val uri = pdfUri!!
                        val pageIndex = currentPage.coerceIn(0, pageCount - 1)
                        val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = uri, key2 = pageIndex, key3 = pdfPassword) {
                            value = withContext(Dispatchers.IO) { renderPage(context, uri, pageIndex, pdfPassword) }
                        }
                        Column(Modifier.fillMaxSize()) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(pdfName, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text("${(zoom * 100).toInt()}% · ${activeTool.replaceFirstChar { it.uppercase() }}", color = Color.Gray, fontSize = 11.sp)
                            }
                            BoxWithConstraints(Modifier.fillMaxSize().padding(8.dp).clipToBounds(), contentAlignment = Alignment.Center) {
                                val viewportWidthPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxWidth.toPx() }
                                val viewportHeightPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxHeight.toPx() }
                                val baseWidthPx = viewportWidthPx
                                val baseHeightPx = if (bitmap != null && bitmap!!.width > 0) baseWidthPx * bitmap!!.height.toFloat() / bitmap!!.width.toFloat() else viewportHeightPx
                                if (bitmap != null) {
                                    Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "PDF page ${pageIndex + 1}", modifier = Modifier.fillMaxWidth().graphicsLayer { scaleX = zoom; scaleY = zoom; translationX = panOffset.x; translationY = panOffset.y })
                                    Canvas(Modifier.matchParentSize()) {
                                        val pageLeft = size.width / 2f + panOffset.x - baseWidthPx * zoom / 2f
                                        val pageTop = size.height / 2f + panOffset.y - baseHeightPx * zoom / 2f
                                        translate(pageLeft, pageTop) {
                                            scale(zoom, pivot = Offset.Zero) {
                                                val pageMarks = marks.filter { it.pageIndex == pageIndex }
                                                pageMarks.forEach { mark -> drawMarkPreview(mark, baseWidthPx, baseHeightPx) }
                                                if (inProgressPoints.isNotEmpty()) {
                                                    val temp = PdfMark(activeTool, pageIndex, inProgressPoints)
                                                    drawMarkPreview(temp, baseWidthPx, baseHeightPx)
                                                }
                                            }
                                        }
                                    }
                                } else CircularProgressIndicator()
                                Spacer(Modifier.matchParentSize().pointerInput(activeTool, pageIndex, bitmap, zoom, panOffset) {
                                    if (activeTool == "pan") {
                                        detectTransformGestures { _, pan, zoomChange, _ ->
                                            val nextZoom = (zoom * zoomChange).coerceIn(1f, 5f)
                                            zoom = nextZoom
                                            if (nextZoom <= 1.01f) panOffset = Offset.Zero else {
                                                val maxX = (((baseWidthPx * nextZoom) - viewportWidthPx) / 2f).coerceAtLeast(0f)
                                                val maxY = (((baseHeightPx * nextZoom) - viewportHeightPx) / 2f).coerceAtLeast(0f)
                                                panOffset = Offset((panOffset.x + pan.x).coerceIn(-maxX, maxX), (panOffset.y + pan.y).coerceIn(-maxY, maxY))
                                            }
                                        }
                                    } else {
                                        detectDragGestures(
                                            onDragStart = { start -> inProgressPoints = listOf(screenToPage(start, viewportWidthPx, viewportHeightPx, baseWidthPx, baseHeightPx, zoom, panOffset)) },
                                            onDragEnd = {
                                                if (inProgressPoints.isNotEmpty()) {
                                                    val points = inProgressPoints.toList()
                                                    if (activeTool == "highlight" || activeTool == "underline") {
                                                        if (points.size == 1) inProgressPoints = emptyList() else marks.add(PdfMark(activeTool, pageIndex, listOf(points.first(), points.last())))
                                                    } else if (points.size >= 2) marks.add(PdfMark(activeTool, pageIndex, points))
                                                    inProgressPoints = emptyList()
                                                }
                                            },
                                            onDragCancel = { inProgressPoints = emptyList() },
                                            onDrag = { change, _ ->
                                                change.consume()
                                                val point = screenToPage(change.position, viewportWidthPx, viewportHeightPx, baseWidthPx, baseHeightPx, zoom, panOffset)
                                                inProgressPoints = inProgressPoints + point
                                            }
                                        )
                                    }
                                })
                            }
                            Text(if (activeTool == "pan") "Pinch to zoom · Drag to pan" else "Drag on page to add ${activeTool}", Modifier.align(Alignment.CenterHorizontally).padding(6.dp), color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (showTextDialog) AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text("Add text note") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Note current page ke top par add hogi. Basic Latin characters supported hain."); OutlinedTextField(value = noteText, onValueChange = { noteText = it }, label = { Text("Text") }, singleLine = true) } },
            confirmButton = { TextButton(onClick = { showTextDialog = false; pendingEdit = "note"; savePdfLauncher.launch("PDFSaathi-noted.pdf") }) { Text("Save to new PDF") } },
            dismissButton = { TextButton(onClick = { showTextDialog = false }) { Text("Cancel") } }
        )

        if (showPasswordDialog) AlertDialog(
            onDismissRequest = { },
            title = { Text("PDF password required") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Is PDF ko kholne ke liye uska password enter karo.")
                OutlinedTextField(value = passwordInput, onValueChange = { passwordInput = it; passwordError = null }, label = { Text("PDF password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), isError = passwordError != null)
                if (passwordError != null) Text(passwordError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            } },
            confirmButton = { TextButton(onClick = { if (passwordInput.isNotEmpty()) { pdfPassword = passwordInput; error = null } else passwordError = "Password enter karo." }) { Text("Open PDF") } },
            dismissButton = { TextButton(onClick = { showPasswordDialog = false; pdfPassword = null; pdfUri = null; pdfName = "No PDF opened"; pageCount = 0; error = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ToolChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(label) })
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawMarkPreview(mark: PdfMark, pageWidth: Float, pageHeight: Float) {
    if (mark.points.isEmpty()) return
    val pts = mark.points.map { Offset(it.x * pageWidth, it.y * pageHeight) }
    when (mark.type) {
        "highlight" -> {
            if (pts.size >= 2) {
                val left = min(pts.first().x, pts.last().x)
                val right = max(pts.first().x, pts.last().x)
                val top = min(pts.first().y, pts.last().y)
                val bottom = max(pts.first().y, pts.last().y)
                drawRect(Color(0x66FFE45C), topLeft = Offset(left, top - 5f), size = androidx.compose.ui.geometry.Size((right-left).coerceAtLeast(8f), (bottom-top).coerceAtLeast(12f)))
            }
        }
        "underline" -> {
            if (pts.size >= 2) drawLine(Color(0xFF2458E8), Offset(pts.first().x, pts.first().y), Offset(pts.last().x, pts.last().y), strokeWidth = 3f, cap = StrokeCap.Round)
        }
        else -> {
            if (pts.size >= 2) {
                val path = Path().apply { moveTo(pts.first().x, pts.first().y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                drawPath(path, if (mark.type == "signature") Color(0xFF142B85) else Color(0xFF2458E8), style = Stroke(width = if (mark.type == "signature") 3.2f else 2.5f, cap = StrokeCap.Round))
            }
        }
    }
}

private fun screenToPage(position: Offset, viewportWidth: Float, viewportHeight: Float, pageWidth: Float, pageHeight: Float, zoom: Float, pan: Offset): Offset {
    val x = (position.x - viewportWidth / 2f - pan.x) / zoom + pageWidth / 2f
    val y = (position.y - viewportHeight / 2f - pan.y) / zoom + pageHeight / 2f
    return Offset((x / pageWidth.coerceAtLeast(1f)).coerceIn(0f, 1f), (y / pageHeight.coerceAtLeast(1f)).coerceIn(0f, 1f))
}

@Composable
private fun EmptyState(title: String, body: String, buttonText: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Blue, modifier = Modifier.size(64.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(body, color = Color.Gray)
            Button(onClick = onClick) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(buttonText) }
        }
    }
}

private fun queryDisplayName(context: Context, uri: Uri): String? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }

private fun loadDocument(context: Context, uri: Uri, password: String?): PDDocument {
    PDFBoxResourceLoader.init(context.applicationContext)
    val input = context.contentResolver.openInputStream(uri) ?: throw IllegalStateException("File open nahi ho paayi.")
    return input.use { PDDocument.load(it, password ?: "") }
}

private fun renderPage(context: Context, uri: Uri, index: Int, password: String?): android.graphics.Bitmap? = try {
    loadDocument(context, uri, password).use { document -> if (index !in 0 until document.numberOfPages) null else PDFRenderer(document).renderImage(index, 1.5f, ImageType.RGB) }
} catch (_: Exception) { null }

private fun sharePdf(context: Context, uri: Uri?) {
    if (uri == null) return
    val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    context.startActivity(Intent.createChooser(intent, "Share PDF"))
}
