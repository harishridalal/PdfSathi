package com.pdfsaathi.app

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.graphics.pdf.LoadParams
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.content.Intent
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlin.math.hypot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

private val Ink = Color(0xFF172033)
private val Blue = Color(0xFF315EFB)
private val CanvasBg = Color(0xFFF2F4F8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PdfSaathiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfSaathiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    var pdfName by remember { mutableStateOf("No PDF opened") }
    var pageCount by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pdfPassword by remember { mutableStateOf<String?>(null) }
    var passwordInput by remember { mutableStateOf("") }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    val bitmaps = remember { ConcurrentHashMap<Int, Bitmap>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            pdfUri = uri
            pdfName = queryDisplayName(context, uri) ?: "Document.pdf"
            currentPage = 0
            pageCount = 0
            zoom = 1f
            pdfPassword = null
            passwordInput = ""
            passwordError = null
            showPasswordDialog = false
            bitmaps.values.forEach { if (!it.isRecycled) it.recycle() }
            bitmaps.clear()
            error = null
        }
    }

    LaunchedEffect(pdfUri, pdfPassword) {
        val uri = pdfUri ?: return@LaunchedEffect
        busy = true
        try {
            val count = withContext(Dispatchers.IO) {
                openPdfRenderer(context, uri, pdfPassword).use { it.pageCount }
            }
            pageCount = count
            error = null
            showPasswordDialog = false
            passwordError = null
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 35) {
                passwordError = if (pdfPassword.isNullOrEmpty()) {
                    "Yeh PDF password-protected hai. Password enter karo."
                } else {
                    "Password galat hai. Dobara try karo."
                }
                passwordInput = ""
                showPasswordDialog = true
            } else {
                error = "Is Android version par built-in PDF engine password-protected PDFs support nahi karta. Android 15 (API 35) ya newer par try karo."
            }
        } catch (e: Exception) {
            error = "PDF open nahi hui: ${e.localizedMessage ?: "unknown error"}"
        } finally {
            busy = false
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            onPrimary = Color.White,
            background = CanvasBg,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PDF Saathi", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text(pdfName, fontSize = 11.sp, maxLines = 1)
                        }
                    },
                    actions = {
                        IconButton(onClick = { picker.launch(arrayOf("application/pdf")) }) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "Open PDF")
                        }
                        IconButton(onClick = { showTools = !showTools }) {
                            Icon(Icons.Default.Edit, contentDescription = "PDF tools")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                if (pageCount > 0) {
                    Surface(shadowElevation = 8.dp, color = Color.White) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(onClick = { currentPage = (currentPage - 1).coerceAtLeast(0) }) {
                                Icon(Icons.Default.ChevronLeft, contentDescription = "Previous page")
                            }
                            Text("Page ${currentPage + 1} of $pageCount", fontWeight = FontWeight.SemiBold)
                            IconButton(onClick = { currentPage = (currentPage + 1).coerceAtMost(pageCount - 1) }) {
                                Icon(Icons.Default.ChevronRight, contentDescription = "Next page")
                            }
                        }
                    }
                }
            },
            containerColor = CanvasBg
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (showTools) {
                    Card(
                        Modifier.fillMaxWidth().padding(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("PDF tools", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Reader upgrades: two-finger pinch zoom and password-protected PDF opening on Android 15+.", fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                AssistChip(onClick = { zoom = (zoom - 0.2f).coerceAtLeast(0.6f) }, label = { Text("Zoom −") })
                                AssistChip(onClick = { zoom = (zoom + 0.2f).coerceAtMost(4f) }, label = { Text("Zoom +") })
                                AssistChip(onClick = { zoom = 1f }, label = { Text("Reset") })
                                AssistChip(onClick = { sharePdf(context, pdfUri) }, label = { Text("Share") }, leadingIcon = { Icon(Icons.Default.Share, null) })
                            }
                            Text("Next feature modules: markup, signatures, forms, page management, OCR and export.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                when {
                    busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    error != null -> EmptyState("PDF open nahi hui", error ?: "", "Try another PDF") {
                        picker.launch(arrayOf("application/pdf"))
                    }
                    pdfUri == null -> EmptyState(
                        "Your PDFs, one place",
                        "PDF kholne ke liye neeche button dabao. File device ke document picker se select hogi.",
                        "Open a PDF"
                    ) { picker.launch(arrayOf("application/pdf")) }
                    else -> {
                        val uri = pdfUri!!
                        val pageIndex = currentPage.coerceIn(0, (pageCount - 1).coerceAtLeast(0))
                        val bitmap by produceState<Bitmap?>(initialValue = bitmaps[pageIndex], key1 = uri, key2 = pageIndex, key3 = pdfPassword) {
                            value = withContext(Dispatchers.IO) {
                                renderPage(context, uri, pageIndex, 1f, pdfPassword)?.also { bitmaps[pageIndex] = it }
                            }
                        }
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            item {
                                Row(
                                    Modifier.fillMaxWidth().padding(bottom = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(pdfName, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                    Text("${(zoom * 100).toInt()}%", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                            item {
                                if (bitmap != null) {
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                                    ) {
                                        Image(
                                            bitmap = bitmap!!.asImageBitmap(),
                                            contentDescription = "PDF page ${pageIndex + 1}",
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(2.dp)
                                                .graphicsLayer { scaleX = zoom; scaleY = zoom }
                                                .pointerInput(uri, pageIndex) {
                                                    awaitEachGesture {
                                                        awaitFirstDown(requireUnconsumed = false)
                                                        var previousDistance = 0f
                                                        do {
                                                            val event = awaitPointerEvent()
                                                            val pressed = event.changes.filter { it.pressed }
                                                            if (pressed.size >= 2) {
                                                                val p1 = pressed[0].position
                                                                val p2 = pressed[1].position
                                                                val dx = p1.x - p2.x
                                                                val dy = p1.y - p2.y
                                                                val distance = hypot(dx.toDouble(), dy.toDouble()).toFloat()
                                                                if (previousDistance > 0f && distance > 0f) {
                                                                    val factor = distance / previousDistance
                                                                    zoom = (zoom * factor).coerceIn(0.6f, 4f)
                                                                    pressed.forEach { it.consume() }
                                                                }
                                                                previousDistance = distance
                                                            } else {
                                                                previousDistance = 0f
                                                            }
                                                        } while (event.changes.any { it.pressed })
                                                    }
                                                }
                                        )
                                    }
                                } else {
                                    Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator()
                                    }
                                }
                            }
                            item {
                                Text(
                                    "Reader MVP • Page ${pageIndex + 1}",
                                    Modifier.padding(14.dp),
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
        if (showPasswordDialog) {
            AlertDialog(
                onDismissRequest = {
                    showPasswordDialog = false
                    if (pageCount == 0) error = "Password ke bina yeh PDF open nahi ho sakti."
                },
                title = { Text("PDF password required") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Password-protected PDF ka password enter karo.")
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it; passwordError = null },
                            label = { Text("PDF password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            isError = passwordError != null
                        )
                        if (passwordError != null) Text(passwordError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (passwordInput.isNotBlank()) {
                            pdfPassword = passwordInput
                            error = null
                        } else {
                            passwordError = "Password enter karo."
                        }
                    }) { Text("Open PDF") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showPasswordDialog = false
                        error = "Password ke bina yeh PDF open nahi ho sakti."
                    }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String, buttonText: String, onClick: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Blue, modifier = Modifier.size(64.dp))
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(body, color = Color.Gray)
            Button(onClick = onClick) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(buttonText) }
        }
    }
}

private fun queryDisplayName(context: android.content.Context, uri: Uri): String? {
    return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
}

private fun openPdfRenderer(
    context: android.content.Context,
    uri: Uri,
    password: String?
): PdfRenderer {
    val fd = context.contentResolver.openFileDescriptor(uri, "r")
        ?: throw IllegalStateException("File open nahi ho paayi.")
    return try {
        if (Build.VERSION.SDK_INT >= 35) {
            PdfRenderer(fd, LoadParams.Builder().setPassword(password).build())
        } else {
            if (!password.isNullOrEmpty()) {
                fd.close()
                throw UnsupportedOperationException("Password-protected PDFs require Android 15 or newer in this build.")
            }
            PdfRenderer(fd)
        }
    } catch (t: Throwable) {
        try { fd.close() } catch (_: Exception) {}
        throw t
    }
}

private fun renderPage(context: android.content.Context, uri: Uri, index: Int, scale: Float, password: String?): Bitmap? {
    return try {
        openPdfRenderer(context, uri, password).use { renderer ->
            if (index !in 0 until renderer.pageCount) return null
            renderer.openPage(index).use { page ->
                val width = (page.width * 1.4f * scale).toInt().coerceIn(400, 2200)
                val height = (page.height.toFloat() / page.width * width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, Matrix(), PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            }
        }
    } catch (_: Exception) { null }
}

private fun sharePdf(context: android.content.Context, uri: Uri?) {
    if (uri == null) return
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share PDF"))
}
