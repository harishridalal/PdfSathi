# PDF Saathi — Android project

Native Kotlin + Jetpack Compose PDF reader starter.

## Features in this build
- Open a PDF using Android's document picker
- Render and navigate pages
- Two-finger pinch-to-zoom, plus/minus zoom controls and reset
- Share the currently opened PDF
- Password prompt and password-protected PDF reading through Android's built-in `PdfRenderer` on Android 15 / API 35 or newer

## Password support notes
The password-enabled `PdfRenderer` constructor is available from Android API 35. On older Android versions this build reports that the password-protected file is unsupported. Wrong passwords are rejected and the prompt is shown again. Passwords are held in app memory only while the document is open.

## Not yet implemented
This is not yet a complete Adobe Acrobat replacement. Persistent highlights/annotations, editing existing text, signing, form filling, merge/split/reorder pages, OCR, compression, conversion, search and bookmarks need separate implementation and testing. The tools panel is a small reader-controls panel, not a claim that these advanced tools already work.

## Build
Open this project in Android Studio or use the included GitHub Actions workflow to build a debug APK in the cloud. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Java 17 and compileSdk 35.

PDF contents remain on-device; this build does not upload PDFs to a server. Review dependency licenses, test on real devices, and add a privacy policy before any public release.
